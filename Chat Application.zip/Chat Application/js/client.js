//websocket creates 2-way connectn b/w client and server, so that they can transfer update to each other
// websocket (ws) and websocket secure protocol (wss).
//websocket is implemented by Nodejs socket IO library , used to make video calling apps, chat apps.
//socket io is a library that enables real time, bidirectional and event based communication b/w web server
// and client.(Web server can emit an event and client can listen that event and take actions accordingly with
//the help of in browser JS in client and vice-e-versa).

const socket = io ("http://localhost:8000");
const form  = document.getElementById('send-container');
const messageInput = document.getElementById("txt");
const messageContainer= document.querySelector(".container"); // all incoming msg will go in container.
var audio = new Audio('whatsapp.mp3');

const append = (message,position)=>{
    messageelement = document.createElement('div');
    messageelement.innerText = message;
    messageelement.classList.add('message');
    messageelement.classList.add(position);
    messageContainer.append(messageelement);
    if(position=='left'){
    audio.play();}
}

form.addEventListener('submit',(e)=>{
    e.preventDefault(); //page will not reload
    const message = messageInput.value;
    append(`${message}`,"right");
    socket.emit('send',message);
    messageInput.value= '';
})
const name = prompt("Enter your name to join"); 
socket.emit('new-user-joined',name);

socket.on('user-joined',name=>{
    append(`${name} joined the chat`,"right");
})

socket.on('receive',data=>{
    append(`${data.name}: ${data.message}`,"left");
})

socket.on('leave',name=>{
    append(`${name} leave the chat`,"left");
})