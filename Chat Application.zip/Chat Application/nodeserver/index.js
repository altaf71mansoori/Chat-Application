//Node server which will handle socket io connections.
const io = require('socket.io')(8000);  /*socket.io server is a http instance and it is given to io 
and this socekt.io server will listen to incoming events. */

let users = {};

io.on('connection', socket => {    /*io.on will listen to many socket connections and as soon as connection come in this socket then run arrow functn*/
    socket.on('new-user-joined', name => {   /*'new-user-joined' is custom event,socket.on will handle the actions with particular connections */
        console.log("new user joined",name);
        users[socket.id] = name;
        socket.broadcast.emit('user-joined', name);//it will send all the users the newly joined person name when user-joined event is emitted by server to client.
    })


    socket.on('send', message => {     //when send event is called then message will send to all users.
        socket.broadcast.emit('receive', { message: message, name: users[socket.id] }) ;  //receive is event
    })

    socket.on('disconnect', message => {
        socket.broadcast.emit('leave', users[socket.id]) ;
        delete users[socket.id];
    })
})